package kit.se.capstone2.chat.interfaces.dto;

public enum MessageType {
	NEW, CLOSE
}
