package kit.se.capstone2.file.utils;

import lombok.Getter;

public enum ImageType {
	LICENSE,
	PROFILE;

}
