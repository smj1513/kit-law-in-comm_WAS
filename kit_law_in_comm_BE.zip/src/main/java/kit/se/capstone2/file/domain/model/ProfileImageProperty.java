package kit.se.capstone2.file.domain.model;

import jakarta.persistence.Entity;
import jakarta.persistence.OneToOne;
import kit.se.capstone2.user.domain.model.BaseUser;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Entity
@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ProfileImageProperty extends FileProperty {

	@OneToOne
	private BaseUser user;

	@Override
	public void clear() {
		this.user.setProfileImage(null);
		this.user = null;
	}
}
