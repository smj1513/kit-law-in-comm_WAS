package kit.se.capstone2.user.domain.enums;

public enum ApprovalStatus {
	WAITING,
	APPROVED,
	REJECTED
}
