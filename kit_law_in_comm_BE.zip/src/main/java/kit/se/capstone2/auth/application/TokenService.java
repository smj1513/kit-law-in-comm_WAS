package kit.se.capstone2.auth.application;

import kit.se.capstone2.auth.domain.enums.Role;
import kit.se.capstone2.auth.interfaces.request.TokenRequest;
import kit.se.capstone2.auth.jwt.JwtUtils;
import kit.se.capstone2.auth.interfaces.response.LoginResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class TokenService {
	private final JwtUtils jwtUtils;

	private final RedisTemplate<String, String> redisTemplate;

	public LoginResponse refresh(TokenRequest.Refresh request) {
		String refreshToken = request.getRefreshToken();
		jwtUtils.validateRefreshToken(refreshToken);
		String username = jwtUtils.getUsername(refreshToken);
		Role authorities = jwtUtils.getAuthorities(refreshToken);
		UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(username, UUID.randomUUID().toString(), List.of(authorities));
		return jwtUtils.generateToken(usernamePasswordAuthenticationToken);
	}

	public void logout(String accessToken, String userId){

	}


}
