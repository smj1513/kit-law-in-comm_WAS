package kit.se.capstone2.auth.domain.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Pattern;
import kit.se.capstone2.auth.domain.enums.Role;
import kit.se.capstone2.common.entity.BaseTime;
import kit.se.capstone2.user.domain.enums.ApprovalStatus;
import kit.se.capstone2.user.domain.model.BaseUser;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;

@Entity
@Table(
		indexes = {
				@Index(name = "idx_account_user_id_username", columnList = "user_id, username")
		}
)
@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
//@SQLRestriction("approval_status != 'REJECTED'")
public class Account extends BaseTime implements UserDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(unique = true, nullable = false)
	@Pattern(regexp = "^[a-zA-Z0-9]{2,20}", message = "아이디는 2~20자의 영문 대소문자와 숫자로 이루어져야 합니다.")
	private String username;

	@Column(nullable = false)
	private String password;

	private Role role;

	@OneToOne(fetch = FetchType.LAZY)
	private BaseUser user;

	//일반 사용자는 회원가입시 바로 승인, 변호사는 관리자 승인 후 승인
	@Enumerated(EnumType.STRING)
	private ApprovalStatus approvalStatus;


	public void changeApprovalStatus(boolean isApproval) {
		if (isApproval) {
			this.approvalStatus = ApprovalStatus.APPROVED;
		} else {
			this.approvalStatus = ApprovalStatus.REJECTED;
		}
	}


	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return List.of(role);
	}

	@Override
	public String getPassword() {
		return password;
	}

	@Override
	public String getUsername() {
		return username;
	}
}
